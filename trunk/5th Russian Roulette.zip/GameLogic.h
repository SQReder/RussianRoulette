// ---------------------------------------------------------------------------

#ifndef GameLogicH
#define GameLogicH
void switchoffquestion();
void switchonquestion();
void showquestion();
void activatedplayers();
void DeactivateHatches();
void choosenplayer();
void Proverka();
void activate_final_hatches();
void deactivate_final_hatches();
void load_final_question();

// void blabla();
// ---------------------------------------------------------------------------
#endif
