// ---------------------------------------------------------------------------

#ifndef uAnimateH
#define uAnimateH

#include "pngimage.hpp"
// ---------------------------------------------------------------------------
void Initialize();
void NextFrame();

#endif
